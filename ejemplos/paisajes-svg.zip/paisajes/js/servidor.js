// Muestra desde qué nombre de host se está viendo la página (por ejemplo paisajes.cloud.local).
document.getElementById("servidor").textContent = window.location.host || "archivo local";
