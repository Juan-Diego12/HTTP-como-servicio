// Pequeña lógica de cliente para mostrar que también se publican aplicaciones, no solo HTML estático.
document.getElementById("servidor").textContent = window.location.host || "archivo local";

// Contadores que se animan una vez al mostrarse.
const contadores = document.querySelectorAll(".contador");
const animar = (el) => {
  const meta = Number(el.dataset.meta);
  let valor = 0;
  const paso = Math.max(1, Math.round(meta / 40));
  const id = setInterval(() => {
    valor = Math.min(meta, valor + paso);
    el.textContent = valor;
    if (valor === meta) clearInterval(id);
  }, 30);
};
const observador = new IntersectionObserver((entradas) => {
  entradas.forEach((e) => { if (e.isIntersecting) { animar(e.target); observador.unobserve(e.target); } });
});
contadores.forEach((c) => observador.observe(c));

// Formulario de contacto: valida en el navegador (no hay servidor que lo reciba).
document.getElementById("formulario").addEventListener("submit", (evento) => {
  evento.preventDefault();
  const formulario = evento.target;
  const respuesta = document.getElementById("respuesta");
  if (!formulario.checkValidity()) {
    respuesta.textContent = "Complete nombre, un correo válido y el mensaje.";
    respuesta.style.color = "#b42318";
    return;
  }
  respuesta.textContent = `Gracias, ${formulario.nombre.value}. Este sitio es una demostración: el mensaje no se envía.`;
  respuesta.style.color = "#1e7b34";
  formulario.reset();
});
